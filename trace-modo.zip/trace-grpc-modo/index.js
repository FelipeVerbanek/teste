const { getModo } = require('modo-client')

process.env.LIB_URL_MODO_CLIENT = "172.19.132.61:50051"

const findIniModo = async () => {
    const cnpj = "47960950116260"
    const grupo = "MagazineLuiza"
    const documento = "nfse"

    const inicio = Date.now(); // Obtém o tempo atual em milissegundos
    const ini = await getIni({
        cnpj,
        grupo,
        documento
      })

    const fim = Date.now(); // Obtém o tempo atual após a execução da função
    const tempoDecorrido = fim - inicio; // Calcula o tempo decorrido em milissegundos

    console.log("Tempo de execução: " + tempoDecorrido + " milissegundos");
      
}

const getIni = async (
    getIniParams) => {
    const {
      cnpj,
      documento,
      grupo,
      nomeCidade,
      textIni
    } = getIniParams

    return await getModo({
      cnpj,
      documento,
      getvencimentocertificado: 0,
      grupo,
      nomeCidade,
      user: "admin",
      textIni
    })
}

findIniModo().then(()=> console.log("ok")).catch(err => console.log(err))